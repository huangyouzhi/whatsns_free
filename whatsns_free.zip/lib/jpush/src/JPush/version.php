<?php
namespace JPush;

  const VERSION = '3.6.1';
