<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><link href=https://cdn.jsdelivr.net/npm/animate.css@3.5.1 rel=stylesheet type=text/css>
<title>WHATSNS问答系统安装</title>　
<script>var _installurl=window.location.href;
    var CURRENTURL = _installurl.substring(0,_installurl.lastIndexOf('install'));

    var _tmplocation= _installurl.substring(0,_installurl.lastIndexOf('install')-1);
    var dirName = _tmplocation.substring(_tmplocation.lastIndexOf('/')+1,_tmplocation.length);</script><link href=./static/css/app.bb563e8ce6222c773e8fbbe675dcd082.css rel=stylesheet></head><body><div id=app></div><script type=text/javascript src=./static/js/manifest.2ae2e69a05c33dfc65f8.js></script><script type=text/javascript src=./static/js/vendor.c30c1c41b84105000361.js></script><script type=text/javascript src=./static/js/app.0d1e067cbec1b0f5f9e6.js></script></body></html>