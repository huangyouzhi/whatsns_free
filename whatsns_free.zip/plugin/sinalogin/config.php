<?php 
define('WB_AKEY',  'dddsdsad');
define('WB_SKEY',  'dsadsadsadsads');
define('WB_CALLBACK_URL',  'http://www.dianbo.com/plugin/sinalogin/callback.php');
