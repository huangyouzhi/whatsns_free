<?php
$urllist=array(

    '搜索引擎类问答'=>array(
      '360问答分类'=>'sowenda_ask2.txt'
    ),
    '母婴相关'=>array(
	 '摇篮问答分类采集'=>'yaolanwenda.txt',
	  '摇篮问答关键词搜索采集'=>'yaolanwendasousuo.txt',
	 
	   'babytree育儿问答首页'=>'babytree_ask2.txt',
     'babytree育儿问答关键词搜索'=>'babytreesousuo_ask2.txt',
     'babytree育儿问答标签采集'=>'babytreebiaoqian_ask2.txt'
    
    ),'汽车'=>array(
	     '易车-汽车问答首页列表'=>'bitautoshouye.txt',
    '易车-汽车问答分类检索'=>'bitauto_ask2.txt'
    )
    ,
    '医疗'=>array(
	   '120问答'=>'120ask_ask2.txt'
    
    ),
    '法律'=>array(
    '110法律问答'=>'falv110ask_ask2.txt'
    
    ),
   

    '理财'=>array(
    		'币问'=>'biwen_ask2.txt',
    		
    '希财问答采集'=>'csai.txt'
    )

);
	
